function Rectangle(length,width){

        this.length = length;
        this.width = width;
        this.getArea = function(){
            return this.length * this.width;

    };
}


let square1 = new Rectangle(7,4);
console.log(`1. Rechteck: 
Länge = ${square1.length}, Breite = ${square1.width}, Fläche = ${square1.getArea()}`);

let square2 = new Rectangle(30,5);
console.log(`2. Rechteck: 
Länge = ${square2.length}, Breite = ${square2.width}, Fläche = ${square2.getArea()}`);